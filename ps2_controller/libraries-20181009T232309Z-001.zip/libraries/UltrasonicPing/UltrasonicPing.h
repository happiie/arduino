/*
UltrasonicPing.h - Library for UltrasonicPing
for 4pin sensor :1 pin for trigger and 1 pin for echo
for 3pin sensor : both pin can be define the same
UltrasonicPing anyname(TrigPin, EchoPin)
anyname.trigger() to trigger the sensor

anyname.read()  return duration in microseconds
anyname.read_cm() return distance in cm
anyname.read_inch() return distance in inches

Created by Kok Chee Khean, 24 November 2013
For Roboplus Multi-purpose Educational Basic Shield
*/

#ifndef UltrasonicPing_h
#define UltrasonicPing_h

class UltrasonicPing
{
	public:
		UltrasonicPing(int TrigPin, int EchoPin);
		void trigger();
		long read_cm();
		long read_inch();
		long read();

	private:
		int _TrigPin;
		int _EchoPin;
		long _duration;
};



#endif