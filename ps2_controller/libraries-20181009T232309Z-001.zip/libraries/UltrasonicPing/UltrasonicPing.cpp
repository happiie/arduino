/*
UltrasonicPing.cpp - Library for UltrasonicPing
for 4pin sensor :1 pin for trigger and 1 pin for echo
for 3pin sensor : both pin can be define the same
UltrasonicPing anyname(TrigPin, EchoPin)
anyname.trigger() to trigger the sensor

anyname.read()  return duration in microseconds
anyname.read_cm() return distance in cm
anyname.read_inch() return distance in inches

Created by Kok Chee Khean, 24 November 2013
For Roboplus Multi-purpose Educational Basic Shield
*/

#include "Arduino.h"
#include "UltrasonicPing.h"

UltrasonicPing::UltrasonicPing(int TrigPin, int EchoPin)
{
	_TrigPin=TrigPin;
	_EchoPin=EchoPin;	
}

long UltrasonicPing::read()
{
	return _duration;
}

long UltrasonicPing::read_cm()
{
	return (_duration/ 29 / 2);
}

long UltrasonicPing::read_inch()
{
	return (_duration/ 74 / 2);
}

void UltrasonicPing::trigger()
{
	long duration;
	pinMode(_TrigPin, OUTPUT);
  	digitalWrite(_TrigPin, LOW);
  	delayMicroseconds(2);
  	digitalWrite(_TrigPin, HIGH);
  	delayMicroseconds(5);
  	digitalWrite(_TrigPin, LOW);

	pinMode(_EchoPin, INPUT);
 	_duration = pulseIn(_EchoPin, HIGH);
	
}


