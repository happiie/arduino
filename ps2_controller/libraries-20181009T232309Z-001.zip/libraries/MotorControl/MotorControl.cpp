/*
MotorControl.cpp - Library for DC brushed motor driver control 
with 1 Digital IO and 1 PWM pin
for H-bridge or MotorDriver
Created by Kok Chee Khean, 21 November 2013
For Roboplus Multi-purpose Educational Basic Shield
*/

#include "Arduino.h"
#include "MotorControl.h"
//#include <SoftPWM.h>

MotorControl::MotorControl(int MDIRPin, int MPWMPin ,int polar, char H_M)
{
		//SoftPWMBegin();
	pinMode(MDIRPin, OUTPUT); _MDIRPin=MDIRPin;
	pinMode(MPWMPin, OUTPUT); _MPWMPin=MPWMPin;
	if (H_M=='M' && polar==0) { _PLL=0; _PUL=255; _NLL=255; _NUL=0; _DIR=0;	}
   else if (H_M=='M' && polar==1) { _PLL=0; _PUL=255; _NLL=255; _NUL=0; _DIR=1;	}
   else if (H_M=='H' && polar==0) { _PLL=0; _PUL=255; _NLL=0; _NUL=255; _DIR=0;	}
   else if (H_M=='H' && polar==1) { _PLL=255; _PUL=0; _NLL=255; _NUL=0; _DIR=1;	}
}


void MotorControl::speed(int Mvalue)
{
	Mvalue=constrain(Mvalue,-254,255);
	if(Mvalue>=0) 
	{ 
		digitalWrite(_MDIRPin, _DIR); 
		analogWrite(_MPWMPin, map(Mvalue,0,255,_PLL,_PUL));
		//	SoftPWMSet(_MPWMPin, map(Mvalue,0,255,_PLL,_PUL));
	}
	else 
	{ 
		digitalWrite(_MDIRPin, !_DIR);
		analogWrite(_MPWMPin,map(Mvalue,-254,0,_NLL,_NUL));
		//	SoftPWMSet(_MPWMPin,map(Mvalue,-254,0,_NLL,_NUL));
	}
}


