/*
MotorControl.h - Library for DC brushed motor driver control 
with 1 Digital IO and 1 PWM pin
for H-bridge or MotorDriver
Created by Kok Chee Khean, 21 November 2013
For Roboplus Multi-purpose Educational Basic Shield
*/

#ifndef MotorControl_h
#define MotorControl_h

class MotorControl
{
	public:
		MotorControl(int MDIRPin, int MPWMPin ,int polar, char H_M);
			void speed(int Mvalue);
	private:
		int _MDIRPin;
		int _MPWMPin;
		int _PLL;
		int _PUL;
		int _NLL;
		int _NUL;
		int _DIR;
};



#endif