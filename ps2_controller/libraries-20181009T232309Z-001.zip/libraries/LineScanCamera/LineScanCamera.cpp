/*
LineScanCamera.cpp - Library for LineScanCamera.
Created by Kok Chee Khean, 23 November 2013
For Roboplus Multi-purpose Educational Basic Shield

The methods are:
 
 LineScanCamera - Class for manipulating LineScanCamera connected to Arduino pins. 
 LineScanCamera anyname (SIpin, CLKpin, ANpin, Exposetime in us)
 read()      - Gets the analog value of each pixel. return int*

*/


#include "Arduino.h"
#include "LineScanCamera.h"

LineScanCamera::LineScanCamera(int SIpin, int CLKpin, int ANpin, int Texpose)
{
	pinMode(SIpin, OUTPUT); _SIpin=SIpin;
	pinMode(CLKpin, OUTPUT); _CLKpin=CLKpin;
	_ANpin=ANpin;
	_Texpose=Texpose;
}

int* LineScanCamera::read()
{
	static int value[128];

	digitalWrite(_CLKpin, LOW);
	digitalWrite(_SIpin, HIGH);
	digitalWrite(_CLKpin, HIGH);
	digitalWrite(_SIpin, LOW);
	digitalWrite(_CLKpin, LOW);

	for (int j = 0; j < 128; j++)
	{
		digitalWrite(_CLKpin, HIGH);
		digitalWrite(_CLKpin, LOW);
	}

	delayMicroseconds(_Texpose);

	digitalWrite(_SIpin, HIGH);
	digitalWrite(_CLKpin, HIGH);
	digitalWrite(_SIpin, LOW);
	digitalWrite(_CLKpin, LOW);

	for (int j = 0; j < 128; j++)
	{
		delayMicroseconds(20);
		value[j] = analogRead(_ANpin);
		digitalWrite(_CLKpin, HIGH);
		digitalWrite(_CLKpin, LOW);
	}
	delayMicroseconds(20);
	
	return value;
	
}