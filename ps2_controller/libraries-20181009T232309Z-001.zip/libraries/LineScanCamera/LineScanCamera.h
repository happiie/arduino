/*
LineScanCamera.h - Library for LineScanCamera.
Created by Kok Chee Khean, 23 November 2013
For Roboplus Multi-purpose Educational Basic Shield
*/

#ifndef LineScanCamera_h
#define LineScanCamera_h

#include "Arduino.h"

class LineScanCamera
{
	public:
		LineScanCamera(int SIpin, int CLKpin, int ANpin, int Texpose);
		int* read();
	private:		
		int _SIpin;
		int _CLKpin;
		int _ANpin;
		int _Texpose;
};

#endif